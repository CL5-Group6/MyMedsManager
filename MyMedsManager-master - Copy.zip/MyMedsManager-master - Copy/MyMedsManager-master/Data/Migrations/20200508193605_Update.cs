﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MyMedsManager.Data.Migrations
{
    public partial class Update : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Dosage",
                table: "Medication");

            migrationBuilder.DropColumn(
                name: "Frequency",
                table: "Medication");

            migrationBuilder.AddColumn<int>(
                name: "DosageValue",
                table: "Medication",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FrequencyValue",
                table: "Medication",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DosageValue",
                table: "Medication");

            migrationBuilder.DropColumn(
                name: "FrequencyValue",
                table: "Medication");

            migrationBuilder.AddColumn<int>(
                name: "Dosage",
                table: "Medication",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Frequency",
                table: "Medication",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
